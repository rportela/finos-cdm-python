version = (6,4,0,0)
version_str = '6.4.0-0'
__version__ = '6.4.0'
__build_time__ = '2025-04-04T15:57:36.173389'