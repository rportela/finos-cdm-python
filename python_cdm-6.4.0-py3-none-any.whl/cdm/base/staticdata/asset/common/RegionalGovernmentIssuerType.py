# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import List, Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rosetta.runtime.utils import (
    BaseDataClass, rosetta_condition, rosetta_resolve_attr, rosetta_resolve_deep_attr
)
from rosetta.runtime.utils import *

__all__ = ['RegionalGovernmentIssuerType']


class RegionalGovernmentIssuerType(BaseDataClass):
    """
    Represents a class to allow specification of different type of Regional government collateral.
    """
    sovereignRecourse: bool = Field(..., description="Applies to regional governments, local authorities or municipals. True if entity has recourse to sovereign (e.g. debt guaranteed by government). False if entity does not have recourse to sovereign.")
    """
    Applies to regional governments, local authorities or municipals.  True if entity has recourse to sovereign (e.g. debt guaranteed by government).  False if entity does not have recourse to sovereign.
    """

import cdm 
